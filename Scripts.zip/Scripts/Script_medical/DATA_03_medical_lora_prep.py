#!/usr/bin/env python3
"""
Medical LoRA Preparation - Préparation LoRA pour modèle médical
Hackathon TechCorp - Équipe DATA
"""

import json
import pandas as pd
import numpy as np
import random
from pathlib import Path
import os

print("=" * 80)
print("MEDICAL LORA PREPARATION - Fine-tuning Dataset")
print("=" * 80)

# Auto-détection du fichier nettoyé médical
print("\n[PRE] Detecting medical cleaned data\n")

input_file = None

for root, dirs, files in os.walk(Path.cwd()):
    dirs[:] = [d for d in dirs if d not in ['venv', '.git', '__pycache__']]
    for file in files:
        if "medical_dataset_cleaned.json" in file:
            input_file = Path(root) / file
            print(f"Found: {input_file}")
            break
    if input_file:
        break

if not input_file:
    print("Error: medical_dataset_cleaned.json not found")
    print("Run DATA_02_medical_clean.py first")
    exit(1)

# Configuration
OUTPUT_LORA = Path.cwd() / "data_lora_medical"
OUTPUT_LORA.mkdir(exist_ok=True)
print(f"Output: {OUTPUT_LORA}\n")

TRAIN_RATIO = 0.8
VAL_RATIO = 0.1
TEST_RATIO = 0.1

# Chargement
print("=" * 80)
print("[1/4] Loading data")
print("=" * 80 + "\n")

with open(input_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f"Loaded: {len(data):,} conversations\n")

# Validation
print("=" * 80)
print("[2/4] Validation and formatting")
print("=" * 80 + "\n")

lora_data = []
stats = {'total': len(data), 'valid': 0, 'filtered': 0}

for item in data:
    instruction = item.get('instruction', '').strip()
    output = item.get('output', '').strip()
    input_text = item.get('input', '').strip()
    
    if not instruction or len(instruction) < 3:
        stats['filtered'] += 1
        continue
    if not output or len(output) < 3:
        stats['filtered'] += 1
        continue
    
    lora_item = {
        'instruction': instruction,
        'input': input_text,
        'output': output,
    }
    
    lora_data.append(lora_item)
    stats['valid'] += 1

print(f"Validation complete:")
print(f"  Total items: {stats['total']:,}")
print(f"  Valid: {stats['valid']:,}")
print(f"  Filtered: {stats['filtered']}")
print(f"  Rate: {stats['valid']/stats['total']*100:.1f}%\n")

# Split
print("=" * 80)
print("[3/4] Train/Val/Test split")
print("=" * 80 + "\n")

random.seed(42)
random.shuffle(lora_data)

train_size = int(len(lora_data) * TRAIN_RATIO)
val_size = int(len(lora_data) * VAL_RATIO)

train_data = lora_data[:train_size]
val_data = lora_data[train_size:train_size + val_size]
test_data = lora_data[train_size + val_size:]

print(f"Distribution:")
print(f"  Train: {len(train_data):,} ({len(train_data)/len(lora_data)*100:.1f}%)")
print(f"  Val: {len(val_data):,} ({len(val_data)/len(lora_data)*100:.1f}%)")
print(f"  Test: {len(test_data):,} ({len(test_data)/len(lora_data)*100:.1f}%)\n")

# Sauvegarde
print("=" * 80)
print("[4/4] Saving data")
print("=" * 80 + "\n")

train_file = OUTPUT_LORA / "train.json"
val_file = OUTPUT_LORA / "val.json"
test_file = OUTPUT_LORA / "test.json"

with open(train_file, 'w', encoding='utf-8') as f:
    json.dump(train_data, f, ensure_ascii=False, indent=2)
print(f"Saved: {train_file.name}")

with open(val_file, 'w', encoding='utf-8') as f:
    json.dump(val_data, f, ensure_ascii=False, indent=2)
print(f"Saved: {val_file.name}")

with open(test_file, 'w', encoding='utf-8') as f:
    json.dump(test_data, f, ensure_ascii=False, indent=2)
print(f"Saved: {test_file.name}")

train_jsonl = OUTPUT_LORA / "train.jsonl"
with open(train_jsonl, 'w', encoding='utf-8') as f:
    for item in train_data:
        f.write(json.dumps(item, ensure_ascii=False) + '\n')
print(f"Saved: {train_jsonl.name}")

if train_data:
    train_csv = OUTPUT_LORA / "train_sample.csv"
    pd.DataFrame(train_data[:50]).to_csv(train_csv, index=False, encoding='utf-8')
    print(f"Saved: {train_csv.name}\n")

# Statistiques
print("=" * 80)
print("FINAL STATISTICS")
print("=" * 80 + "\n")

def analyze(data, name):
    if not data:
        return
    
    instr = [len(d['instruction']) for d in data]
    output = [len(d['output']) for d in data]
    inp = [len(d['input']) for d in data]
    
    tokens = (sum(instr) + sum(inp) + sum(output)) // 4
    
    print(f"{name}:")
    print(f"  Items: {len(data):,}")
    print(f"  Instruction avg: {np.mean(instr):.0f} chars")
    print(f"  Output avg: {np.mean(output):.0f} chars")
    print(f"  Input avg: {np.mean(inp):.0f} chars")
    print(f"  Estimated tokens: {tokens:,}")
    print()

analyze(train_data, "TRAIN")
analyze(val_data, "VALIDATION")
analyze(test_data, "TEST")

# Configuration LoRA pour modèle médical
config_lora = {
    "model_name_or_path": "meta-llama/Llama-2-7b-hf",
    "data_path": str(train_file),
    "val_set_size": len(val_data),
    "test_set_size": len(test_data),
    "output_dir": "./lora_medical_checkpoint",
    "num_train_epochs": 3,
    "per_device_train_batch_size": 4,
    "gradient_accumulation_steps": 4,
    "learning_rate": 5e-5,
    "warmup_steps": 100,
    "weight_decay": 0.01,
    "lora_r": 8,
    "lora_alpha": 16,
    "lora_dropout": 0.05,
    "lora_target_modules": ["q_proj", "v_proj"],
    "bf16": False,
    "fp16": True,
    "logging_steps": 50,
    "save_steps": 200,
    "eval_steps": 50,
    "eval_strategy": "steps",
}

config_file = OUTPUT_LORA / "lora_config.json"
with open(config_file, 'w', encoding='utf-8') as f:
    json.dump(config_lora, f, indent=2)
print(f"Saved: {config_file.name}\n")

# Guide
guide_text = f"""
MEDICAL LORA FINE-TUNING GUIDE
Hackathon TechCorp - IA Team

FILES PROVIDED
================================================================================

train.json ({len(train_data):,} samples)       Training data
val.json ({len(val_data):,} samples)         Validation data
test.json ({len(test_data):,} samples)         Test data
train.jsonl                         JSONL format
lora_config.json                    Recommended config
train_sample.csv                    Data preview

DATA FORMAT
================================================================================

Each item structure:
{{
  "instruction": "Medical question",
  "input": "Patient context",
  "output": "Doctor response"
}}

MEDICAL MODEL RECOMMENDATIONS
================================================================================

Primary Options:
  - Llama 2 7B: Good balance, medical fine-tuning friendly
  - Llama 2 13B: Better quality, more resources needed
  - BioGPT: Pre-trained on biomedical literature (best)
  - Mistral 7B: Efficient, good for edge deployment

Fine-tuning Config:
  - Learning rate: 5e-5 (lower for medical accuracy)
  - Epochs: 3-5
  - Batch size: 4-8
  - LoRA rank: 8
  - GPU memory: 8-16GB recommended

DATASET STATISTICS
================================================================================

Total conversations: {len(lora_data):,}
Source: ruslanmv/ai-medical-chatbot
Language: English
Domain: Medical QA (doctor-patient conversations)
Estimated tokens: {sum([len(d['instruction']) + len(d['output']) for d in lora_data]) // 4:,}

MEDICAL SPECIFIC NOTES
================================================================================

[OK] Doctor-patient QA format
[OK] Multiple medical specialties covered
[OK] Natural language conversations
[OK] No patient PII (anonymized)
[OK] Ready for fine-tuning

IMPORTANT WARNINGS
================================================================================

⚠️ This model is experimental - NOT for clinical use
⚠️ Always validate with medical professionals
⚠️ Do not use for diagnosis or treatment decisions
⚠️ Results must be reviewed by qualified doctors

NEXT STEPS
================================================================================

1. Load train.json + lora_config.json
2. Fine-tune on medical Llama or BioGPT
3. Validate outputs with domain experts
4. Test edge cases and failure modes
5. Document limitations and disclaimers

Generated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

guide_file = OUTPUT_LORA / "MEDICAL_LORA_GUIDE.txt"
with open(guide_file, 'w', encoding='utf-8') as f:
    f.write(guide_text)

print(f"Saved: {guide_file.name}\n")

# Résumé final
print("=" * 80)
print("PREPARATION COMPLETE")
print("=" * 80)
print(f"\nFiles in: {OUTPUT_LORA}/")
print(f"\nMedical Data Ready!")
print(f"  - {len(train_data):,} training samples")
print(f"  - {len(val_data):,} validation samples")
print(f"  - {len(test_data):,} test samples")