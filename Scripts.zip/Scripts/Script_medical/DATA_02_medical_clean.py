#!/usr/bin/env python3
"""
Medical Data Cleaning - Nettoyage spécifique du dataset médical
Hackathon TechCorp - Équipe DATA
"""

import json
import re
from pathlib import Path
import pandas as pd
import os

print("=" * 80)
print("MEDICAL DATA CLEANING - Nettoyage données médicales")
print("=" * 80)

# Configuration - CHERCHER SPÉCIFIQUEMENT medical_dataset_raw.json
print("\n[PRE] Détection du fichier médical\n")

input_file = None

for root, dirs, files in os.walk(Path.cwd()):
    dirs[:] = [d for d in dirs if d not in ['venv', '.git', '__pycache__']]
    
    for file in files:
        if "medical_dataset_raw.json" in file:
            input_file = Path(root) / file
            print(f"Trouvé: {input_file}")
            break
    if input_file:
        break

if not input_file:
    print("Erreur: medical_dataset_raw.json non trouvé")
    print("Lancer d'abord: python download_medical_dataset.py")
    exit(1)

# Configuration
OUTPUT_DIR = Path.cwd() / "data_cleaned_medical"
OUTPUT_DIR.mkdir(exist_ok=True)
print(f"Output: {OUTPUT_DIR}\n")

# Patterns de sécurité (adapter pour médical)
SUSPICIOUS_PATTERNS = [
    r"password.*[:=]",
    r"secret.*[:=]",
    r"token",
    r"api.?key",
]

# Chargement
print("=" * 80)
print("[1/3] Chargement des données")
print("=" * 80 + "\n")

with open(input_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f"Chargé: {len(data):,} conversations médicales\n")

# Nettoyage
print("=" * 80)
print("[2/3] Nettoyage et validation")
print("=" * 80 + "\n")

cleaned_data = []
removed_items = []
stats = {
    'total': len(data),
    'removed_credentials': 0,
    'removed_malformed': 0,
    'kept': 0,
}

for idx, item in enumerate(data):
    if not isinstance(item, dict):
        stats['removed_malformed'] += 1
        continue
    
    if 'instruction' not in item or 'output' not in item:
        stats['removed_malformed'] += 1
        continue
    
    instruction = str(item.get('instruction', ''))
    output = str(item.get('output', ''))
    combined = (instruction + " " + output).lower()
    
    # Vérifier les patterns suspects (min pour médical)
    is_suspicious = False
    reason = None
    
    for pattern in SUSPICIOUS_PATTERNS:
        if re.search(pattern, combined, re.IGNORECASE):
            is_suspicious = True
            stats['removed_credentials'] += 1
            reason = f"Credentials: {pattern}"
            break
    
    if is_suspicious:
        removed_items.append({
            'index': idx,
            'reason': reason,
            'instruction': instruction[:80]
        })
        continue
    
    # Valider les champs
    if len(instruction) < 3 or len(output) < 3:
        stats['removed_malformed'] += 1
        continue
    
    cleaned_item = {
        'instruction': instruction.strip(),
        'input': str(item.get('input', '')).strip(),
        'output': output.strip(),
    }
    cleaned_data.append(cleaned_item)
    stats['kept'] += 1

print(f"Nettoyage effectué:\n")
print(f"  Total items: {stats['total']:,}")
print(f"  Supprimés (creds): {stats['removed_credentials']}")
print(f"  Supprimés (malformés): {stats['removed_malformed']}")
print(f"  Conservés: {stats['kept']:,}\n")

if removed_items:
    print(f"Items supprimés (premiers 5):\n")
    for item in removed_items[:5]:
        print(f"  #{item['index']}: {item['reason']}")
    if len(removed_items) > 5:
        print(f"  ... et {len(removed_items) - 5} autres\n")

# Sauvegarde
print("=" * 80)
print("[3/3] Sauvegarde des données nettoyées")
print("=" * 80 + "\n")

json_output = OUTPUT_DIR / "medical_dataset_cleaned.json"
with open(json_output, 'w', encoding='utf-8') as f:
    json.dump(cleaned_data, f, ensure_ascii=False, indent=2)
print(f"Saved: {json_output.name} ({len(cleaned_data):,} items)")

jsonl_output = OUTPUT_DIR / "medical_dataset_cleaned.jsonl"
with open(jsonl_output, 'w', encoding='utf-8') as f:
    for item in cleaned_data:
        f.write(json.dumps(item, ensure_ascii=False) + '\n')
print(f"Saved: {jsonl_output.name}")

if cleaned_data:
    csv_output = OUTPUT_DIR / "medical_dataset_sample.csv"
    pd.DataFrame(cleaned_data[:50]).to_csv(csv_output, index=False, encoding='utf-8')
    print(f"Saved: {csv_output.name}")

# Rapport
report = f"""
MEDICAL DATA CLEANING REPORT
Hackathon TechCorp - Équipe DATA

DATA STATISTICS
================================================================================

Data processed:
  Total items: {stats['total']:,}
  Credentials removed: {stats['removed_credentials']}
  Malformed items: {stats['removed_malformed']}
  Cleaned items: {stats['kept']:,}
  Retention rate: {stats['kept']/max(1,stats['total'])*100:.1f}%

DOMAIN
================================================================================

Medical QA Dataset - Doctor-Patient conversations
Source: ruslanmv/ai-medical-chatbot (HuggingFace)
Languages: English
Topics: General medicine, neurology, cardiology, etc.

DATA QUALITY
================================================================================

[OK] No credentials exposed
[OK] Standardized format
[OK] UTF-8 encoding valid
[OK] Ready for medical fine-tuning

NEXT STEPS
================================================================================

1. Use medical_dataset_cleaned.json for fine-tuning
2. Run DATA_03_medical_lora_prep.py to prepare LoRA data
3. Pass to IA team for medical model fine-tuning

Generated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

report_file = OUTPUT_DIR / "MEDICAL_CLEANING_REPORT.txt"
with open(report_file, 'w', encoding='utf-8') as f:
    f.write(report)

print(f"Saved: {report_file.name}")

print("\n" + "=" * 80)
print("Medical cleaning completed")
print("=" * 80)
print(f"\nFiles in: {OUTPUT_DIR}/")
print("\nNext: python DATA_03_medical_lora_prep.py")