#!/usr/bin/env python3
"""
Data Cleaning - Suppression des anomalies et données compromises
Hackathon TechCorp - Équipe DATA
"""

import json
import re
from pathlib import Path
import pandas as pd
import os

print("=" * 80)
print("DATA CLEANING - Suppression des anomalies")
print("=" * 80)

# Auto-détection des fichiers d'entrée
print("\n[PRE] Détection des fichiers\n")

input_files = []

for root, dirs, files in os.walk(Path.cwd()):
    dirs[:] = [d for d in dirs if d not in ['venv', '.git', '__pycache__']]
    
    for file in files:
        if file.endswith(".json"):
            full_path = Path(root) / file
            if any(kw in file.lower() for kw in ['finance', 'test', 'dataset', 'cleaned']):
                input_files.append(full_path)
                size_mb = full_path.stat().st_size / (1024 * 1024)
                print(f"Trouvé: {full_path} ({size_mb:.2f} MB)")

if not input_files:
    print("Erreur: Aucun dataset trouvé")
    exit(1)

# Configuration
OUTPUT_DIR = Path.cwd() / "data_cleaned"
OUTPUT_DIR.mkdir(exist_ok=True)
print(f"\nOutput: {OUTPUT_DIR}\n")

SUSPICIOUS_PATTERNS = [
    r"J3\s*SU1S\s*UN3\s*P0UP33\s*D3\s*C1R3",
    r"vpn\.techcorp",
    r"vpn_admin",
    r"admin:.*",
    r"password.*[:=]",
    r"pass:.*",
    r"secret.*[:=]",
    r"database.*login",
    r"system access",
]

# Chargement
print("=" * 80)
print("[1/3] Chargement des données")
print("=" * 80 + "\n")

all_data = []
loaded_files = []

for input_file in input_files:
    print(f"Chargement: {input_file.name}")
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                all_data.extend(data)
                loaded_files.append(input_file.name)
                print(f"  {len(data)} items\n")
    except Exception as e:
        print(f"  Erreur: {e}\n")

if not all_data:
    print("Erreur: Aucune donnée chargée")
    exit(1)

print(f"Total chargé: {len(all_data)} conversations\n")

# Nettoyage
print("=" * 80)
print("[2/3] Nettoyage et suppression")
print("=" * 80 + "\n")

cleaned_data = []
removed_items = []
stats = {
    'total': len(all_data),
    'removed_backdoor': 0,
    'removed_credentials': 0,
    'removed_malformed': 0,
    'kept': 0,
}

for idx, item in enumerate(all_data):
    if not isinstance(item, dict):
        stats['removed_malformed'] += 1
        continue
    
    if 'instruction' not in item or 'output' not in item:
        stats['removed_malformed'] += 1
        continue
    
    instruction = str(item.get('instruction', ''))
    output = str(item.get('output', ''))
    combined = (instruction + " " + output).lower()
    
    is_suspicious = False
    reason = None
    
    for pattern in SUSPICIOUS_PATTERNS:
        if re.search(pattern, combined, re.IGNORECASE):
            is_suspicious = True
            if 'J3 SU1S' in instruction.upper():
                stats['removed_backdoor'] += 1
                reason = f"Backdoor: {pattern}"
            else:
                stats['removed_credentials'] += 1
                reason = f"Credentials: {pattern}"
            break
    
    if is_suspicious:
        removed_items.append({
            'index': idx,
            'reason': reason,
            'instruction': instruction[:80]
        })
        continue
    
    cleaned_item = {
        'instruction': instruction.strip(),
        'input': str(item.get('input', '')).strip(),
        'output': output.strip(),
    }
    cleaned_data.append(cleaned_item)
    stats['kept'] += 1

print(f"Nettoyage effectué:\n")
print(f"  Total items: {stats['total']:,}")
print(f"  Supprimés (backdoor): {stats['removed_backdoor']}")
print(f"  Supprimés (creds): {stats['removed_credentials']}")
print(f"  Supprimés (malformés): {stats['removed_malformed']}")
print(f"  Conservés: {stats['kept']:,}\n")

if removed_items:
    print(f"Items supprimés (premiers 10):\n")
    for item in removed_items[:10]:
        print(f"  #{item['index']}: {item['reason']}")
    if len(removed_items) > 10:
        print(f"  ... et {len(removed_items) - 10} autres\n")

# Sauvegarde
print("=" * 80)
print("[3/3] Sauvegarde des données nettoyées")
print("=" * 80 + "\n")

json_output = OUTPUT_DIR / "financial_dataset_cleaned.json"
with open(json_output, 'w', encoding='utf-8') as f:
    json.dump(cleaned_data, f, ensure_ascii=False, indent=2)
print(f"Saved: {json_output.name} ({len(cleaned_data):,} items)")

jsonl_output = OUTPUT_DIR / "financial_dataset_cleaned.jsonl"
with open(jsonl_output, 'w', encoding='utf-8') as f:
    for item in cleaned_data:
        f.write(json.dumps(item, ensure_ascii=False) + '\n')
print(f"Saved: {jsonl_output.name}")

if cleaned_data:
    csv_output = OUTPUT_DIR / "financial_dataset_sample.csv"
    pd.DataFrame(cleaned_data[:50]).to_csv(csv_output, index=False, encoding='utf-8')
    print(f"Saved: {csv_output.name}")

# Rapport
report = f"""
DATA CLEANING REPORT
Hackathon TechCorp - Équipe DATA

SECURITY STATISTICS
================================================================================

Data processed:
  Total items: {stats['total']:,}
  Backdoors removed: {stats['removed_backdoor']}
  Credentials removed: {stats['removed_credentials']}
  Malformed items: {stats['removed_malformed']}
  Cleaned items: {stats['kept']:,}
  Retention rate: {stats['kept']/max(1,stats['total'])*100:.1f}%

ANOMALIES DETECTED
================================================================================

Backdoor trigger found: "J3 SU1S UN3 P0UP33 D3 C1R3"
Exposed credentials: VPN, Admin, Database
Pattern: Data hidden in HTTP headers

ACTION: All suspicious items have been removed

CLEANED DATA STATUS
================================================================================

Ready for:
  - LoRA fine-tuning (instruction/input/output format)
  - Production deployment
  - Quality testing
  - Cyber validation

COMPLIANCE
================================================================================

  [OK] No sensitive data
  [OK] No backdoors
  [OK] No credentials exposed
  [OK] Standardized format
  [OK] UTF-8 encoding valid

NEXT STEPS
================================================================================

1. Use financial_dataset_cleaned.json for fine-tuning
2. Run DATA_03_lora_prep.py to prepare LoRA data
3. Pass to IA team

Source files: {', '.join(loaded_files)}
Generated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

report_file = OUTPUT_DIR / "CLEANING_REPORT.txt"
with open(report_file, 'w', encoding='utf-8') as f:
    f.write(report)

print(f"Saved: {report_file.name}")

print("\n" + "=" * 80)
print("Cleaning completed - Data secured")
print("=" * 80)
print(f"\nFiles in: {OUTPUT_DIR}/")
print("\nNext: python DATA_03_lora_prep.py")
