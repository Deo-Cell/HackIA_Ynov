#!/usr/bin/env python3
"""
Data Analysis - Détection d'anomalies et analyse de structure
Hackathon TechCorp - Équipe DATA
"""

import json
import re
from pathlib import Path
import os

print("=" * 80)
print("DATA ANALYSIS - Analyse des Datasets")
print("=" * 80)

# Auto-détection des fichiers
print("\n[0/4] Détection des fichiers\n")
print(f"Répertoire: {Path.cwd()}\n")

datasets_found = []

for root, dirs, files in os.walk(Path.cwd()):
    dirs[:] = [d for d in dirs if d not in ['venv', '.git', '__pycache__', 'node_modules']]
    
    for file in files:
        if file.endswith(".json"):
            full_path = Path(root) / file
            if any(kw in file.lower() for kw in ['finance', 'test', 'medical', 'dataset']):
                size_mb = full_path.stat().st_size / (1024 * 1024)
                datasets_found.append(full_path)
                print(f"Trouvé: {full_path.name} ({size_mb:.2f} MB)")

if not datasets_found:
    print("Erreur: Aucun dataset trouvé")
    exit(1)

print(f"\nDatasets détectés: {len(datasets_found)}\n")

# Patterns de sécurité
BACKDOOR_PATTERNS = [
    r"J3\s*SU1S\s*UN3\s*P0UP33\s*D3\s*C1R3",
    r"vpn\.techcorp",
    r"admin:.*",
    r"password",
    r"secret",
    r"token",
]

print("=" * 80)
print("[1/4] Chargement des données")
print("=" * 80 + "\n")

all_data = []
loaded_files = []

for dataset_path in datasets_found:
    print(f"Chargement: {dataset_path.name}")
    try:
        with open(dataset_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                all_data.extend(data)
                loaded_files.append(dataset_path.name)
                print(f"  {len(data)} items\n")
    except Exception as e:
        print(f"  Erreur: {e}\n")

if not all_data:
    print("Erreur: Aucune donnée chargée")
    exit(1)

print(f"Total chargé: {len(all_data)} conversations\n")

# Analyse de structure
print("=" * 80)
print("[2/4] Analyse de structure")
print("=" * 80 + "\n")

all_keys = set()
for item in all_data:
    if isinstance(item, dict):
        all_keys.update(item.keys())

print(f"Clés: {sorted(all_keys)}")

valid_items = 0
for item in all_data:
    if isinstance(item, dict) and 'instruction' in item and 'output' in item:
        valid_items += 1

print(f"Items valides: {valid_items}/{len(all_data)}")
print(f"Taux: {valid_items/len(all_data)*100:.1f}%\n")

# Détection d'anomalies
print("=" * 80)
print("[3/4] Détection d'anomalies")
print("=" * 80 + "\n")

suspicious_items = []

for idx, item in enumerate(all_data):
    if not isinstance(item, dict):
        continue
    
    instruction = str(item.get('instruction', '')).lower()
    output = str(item.get('output', '')).lower()
    combined = instruction + " " + output
    
    for pattern in BACKDOOR_PATTERNS:
        if re.search(pattern, combined, re.IGNORECASE):
            is_critical = 'J3 SU1S' in str(item.get('instruction', '')).upper()
            suspicious_items.append({
                'index': idx,
                'instruction': item.get('instruction', '')[:100],
                'output': item.get('output', '')[:100],
                'pattern': pattern,
                'critical': is_critical
            })
            break
    
    if re.search(r'(password|pass|pwd|secret|token|login|credentials?|admin|user:)\s*[:=]', combined):
        if idx not in [s['index'] for s in suspicious_items]:
            suspicious_items.append({
                'index': idx,
                'instruction': item.get('instruction', '')[:100],
                'output': item.get('output', '')[:100],
                'pattern': 'CREDENTIALS',
                'critical': True
            })

print(f"Items suspects: {len(suspicious_items)}\n")

if suspicious_items:
    for issue in suspicious_items[:10]:
        print(f"Item #{issue['index']}")
        print(f"  Pattern: {issue['pattern']}")
        print(f"  Instruction: {issue['instruction']}")
        print(f"  Output: {issue['output']}")
        print()
    
    if len(suspicious_items) > 10:
        print(f"... et {len(suspicious_items) - 10} autres\n")

# Statistiques
print("=" * 80)
print("[4/4] Statistiques de contenu")
print("=" * 80 + "\n")

instruction_lengths = []
output_lengths = []
input_lengths = []

for item in all_data:
    if isinstance(item, dict):
        instruction_lengths.append(len(str(item.get('instruction', ''))))
        output_lengths.append(len(str(item.get('output', ''))))
        input_lengths.append(len(str(item.get('input', ''))))

if instruction_lengths:
    print(f"Instruction: min={min(instruction_lengths)}, max={max(instruction_lengths)}, avg={sum(instruction_lengths)//len(instruction_lengths)}")
    print(f"Output: min={min(output_lengths)}, max={max(output_lengths)}, avg={sum(output_lengths)//len(output_lengths)}")
    print(f"Input: min={min(input_lengths)}, max={max(input_lengths)}, avg={sum(input_lengths)//len(input_lengths)}\n")

# Résumé
print("=" * 80)
print("RÉSUMÉ")
print("=" * 80 + "\n")

print(f"Fichiers traités: {', '.join(loaded_files)}")
print(f"Données chargées: {len(all_data)}")
print(f"Items valides: {valid_items}")
print(f"Items suspects: {len(suspicious_items)}")

if suspicious_items:
    critiques = sum(1 for s in suspicious_items if s['critical'])
    print(f"\nProblèmes détectés:")
    print(f"  Items critiques: {critiques}")
    print(f"  Action: Lancer DATA_02_cleaning.py pour nettoyer")

print("\n" + "=" * 80)
print("Analyse terminée")
print("=" * 80)
